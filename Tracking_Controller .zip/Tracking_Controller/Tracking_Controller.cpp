// -*- C++ -*-
/*!
 * @file  Tracking_Controller.cpp
 * @brief Controller
 * @date $Date$
 *
 * @author Shogo Namatame
 *
 * 修正BSDライセンス
 *
 * $Id$
 */

#include "Tracking_Controller.h"
double PI = 3.1415926535897932384;		//円周率を定義

int scan_data[800]={0};
int field_data[800];
int onece;			//測定の初期動作を判別するための変数（初期動作時は0、以降1となりプログラムは進む）
int onece2;			//測定の初期動作を判別するための変数その2
int lost_swich;		//対象物を見失ったか判断する変数（ある値だけ溜まると初期動作を発動し、対象物を見つけにかかる）
int lost_swich2;
int bf_senter_angl;	//対象物中心角が暴走しないための過去情報を保存する変数（暴走時はこの変数を採用する）
double bf_dist;

// Module specification
// <rtc-template block="module_spec">
static const char* tracking_controller_spec[] =
  {
    "implementation_id", "Tracking_Controller",
    "type_name",         "Tracking_Controller",
    "description",       "Controller",
    "version",           "1.0.0",
    "vendor",            "Shogo Namatame",
    "category",          "Controller",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "0",
    "language",          "C++",
    "lang_type",         "compile",
    // Configuration variables
    "conf.default.stpass_range", "10",
    "conf.default.stpass_limit", "5",
    "conf.default.wkpass_range", "10",
    "conf.default.wkpass_limit", "5",
    "conf.default.pdevide_range", "10",
    "conf.default.pdevide_limit", "0",
    "conf.default.pdevide_delsize", "5",
    "conf.default.cut_range", "40",
    "conf.default.cut_range_other", "100",
    "conf.default.cut_dist", "500",
    "conf.default.cut_dist_other", "500",
    "conf.default.lost_limit", "50",
    "conf.default.max_dist", "2000",
    "conf.default.object_rate", "0.8",
    "conf.default.connect_size", "100",
    // Widget
    "conf.__widget__.stpass_range", "text",
    "conf.__widget__.stpass_limit", "text",
    "conf.__widget__.wkpass_range", "text",
    "conf.__widget__.wkpass_limit", "text",
    "conf.__widget__.pdevide_range", "text",
    "conf.__widget__.pdevide_limit", "text",
    "conf.__widget__.pdevide_delsize", "text",
    "conf.__widget__.cut_range", "text",
    "conf.__widget__.cut_range_other", "text",
    "conf.__widget__.cut_dist", "text",
    "conf.__widget__.cut_dist_other", "text",
    "conf.__widget__.lost_limit", "text",
    "conf.__widget__.max_dist", "text",
    "conf.__widget__.object_rate", "text",
    "conf.__widget__.connect_size", "text",
    // Constraints
    "conf.__constraints__.stpass_range", "0<=x<=40",
    "conf.__constraints__.wkpass_range", "0<=x<=40",
    "conf.__constraints__.pdevide_range", "0<=x<=40",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
Tracking_Controller::Tracking_Controller(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_scanIn("LRF_Scan_Data", m_scan),
    m_Target_PosOut("Target_Pos", m_Target_Pos),
    m_Target_Pos2Out("Target_Pos2", m_Target_Pos2)

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
Tracking_Controller::~Tracking_Controller()
{
}


/*!
 * 各変数を初期化する処理
 */
RTC::ReturnCode_t Tracking_Controller::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  addInPort("LRF_Scan_Data", m_scanIn);
  
  // Set OutPort buffer
  addOutPort("Target_Pos", m_Target_PosOut);
  addOutPort("Target_Pos2", m_Target_Pos2Out);
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

  // <rtc-template block="bind_config">
  // Bind variables and configuration variable
  bindParameter("stpass_range", m_stpass_range, "10");
  bindParameter("stpass_limit", m_stpass_limit, "5");
  bindParameter("wkpass_range", m_wkpass_range, "10");
  bindParameter("wkpass_limit", m_wkpass_limit, "5");
  bindParameter("pdevide_range", m_pdevide_range, "10");
  bindParameter("pdevide_limit", m_pdevide_limit, "0");
  bindParameter("pdevide_delsize", m_pdevide_delsize, "5");
  bindParameter("cut_range", m_cut_range, "40");
  bindParameter("cut_range_other", m_cut_range_other, "100");
  bindParameter("cut_dist", m_cut_dist, "500");
  bindParameter("cut_dist_other", m_cut_dist_other, "500");
  bindParameter("lost_limit", m_lost_limit, "50");
  bindParameter("max_dist", m_max_dist, "2000");
  bindParameter("object_rate", m_object_rate, "0.8");
  bindParameter("connect_size", m_connect_size, "100");
  
  // </rtc-template>
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t Tracking_Controller::onFinalize()
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Tracking_Controller::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Tracking_Controller::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*!
 * field_dataを取得する処理
 */

RTC::ReturnCode_t Tracking_Controller::onActivated(RTC::UniqueId ec_id)
{
	std::cout << "Setting FieldData...." << std::endl;

	int end=0; 
	for(int i=0;i<10;)				//10回目のデータを初期値として利用する
	{
		if (m_scanIn.isNew())
		{
			i++;
			m_scanIn.read();
			for(int j = 44;j <= 725;j++)	//得られたデータを保存変数に順次代入してゆく
			{
				field_data[j] = m_scan.ranges[j];			//受信したデータの値を代入させる
				if (field_data[j]>m_max_dist)field_data[j]=0;	//指定値以下の値は無効とする
			}
		}
		else
		{
			end++;
			if(end>10000000)
			{
				std::cout << "Data does not come" << std::endl;
				return RTC::RTC_ERROR;	//いつまでたってもデータが来ない場合はエラー状態に遷移する
			}
		}
	}

	std::cout << "FieldData Get!!" << std::endl;

  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t Tracking_Controller::onDeactivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*!
 * LRFのデータを取得し人を抽出、モーターに人追跡の動作指示を出す処理
 */

RTC::ReturnCode_t Tracking_Controller::onExecute(RTC::UniqueId ec_id)
{
	bool exist_flag[800]={0};
	bool malti_flag[5][800]={0};
	int move_trace[2]={0};
	int malti_trace[5][2]={0};
	bool filter_ex_point[800]={0};
	int center_angl=0;
	int center_angl_other[5]={0};
	double scan_data_xyt[3][800]={0};		//取得データをそのままx,y,thetaで表現したもの
	double object_xyt[3]={0};				//オブジェクト分割した位置をx,y,thetaで表現したもの
	double malti_object_xyt[5][3]={0};		//複数オブジェクト分割した位置をx,y,thetaで表現したもの
	double main_dist=0;
	int error_number=0;

	if (m_scanIn.isNew())
	{
		/*---------------------------------------------
		　　　　以下はデータ取得と初期処理
		---------------------------------------------*/
		m_scanIn.read();

		for(int i = 44;i <= 725;i++){		//得られたデータを保存変数に順次代入してゆく
			scan_data[i] = m_scan.ranges[i];	//受信したデータの値を代入させる
			if (scan_data[i]>m_max_dist)scan_data[i]=0;	//指定値以下の値は無効とする
			/*
			//もとのデータよりも距離の大きいデータがえられた場合は情報を更新する
			if(scan_data[i]!=0){
				if(scan_data[i]>field_data[i]){
					field_data[i]=scan_data[i];
				}
			}
			*/
		}

		if(onece<10)onece++;	//初期動作と区別するための変数（onece==0なら初期動作）

		/*---------------------------------------------
		　　　以下は取得データから人を検出する処理
		---------------------------------------------*/
		//各関数のエラー内容の告知は関数内に記述
		bkscan_compare(field_data, scan_data, m_object_rate, exist_flag, move_trace);		//背景情報と取得データの比較を行い、変化箇所にフラグを立てる
		if(!strong_pass_filter(m_stpass_range, m_stpass_limit, exist_flag, move_trace, scan_data))	//密度が低過ぎるデータの有効フラグを折る（ごみ取り）
		{
			error_number=1;
		}
		if(!weak_pass_filter(m_wkpass_range, m_wkpass_limit, exist_flag, move_trace, scan_data))		//密度が高い場所にあるデータの欠落を補完（穴埋め）
		{
			error_number=2;
		}
		if(!parson_devid_method(m_pdevide_range, m_pdevide_limit, m_pdevide_delsize, exist_flag, malti_flag, malti_trace))	//得られたデータをオブジェクトごとに分ける
		{
			error_number=3;
		}
		lock_on_method(onece,exist_flag,m_cut_dist,m_cut_range,move_trace,scan_data);				//オブジェクトの存在点から一定の角度、距離以上の有効フラグを折る
		lock_on_method_maltiweak(onece,malti_flag,m_cut_dist_other,m_cut_range_other,malti_trace,scan_data);		//複数オブジェクトに対してのロックオン処理
		if(error_number!=0)
		{
			return RTC::RTC_ERROR;	
		}
		/*--------------------------------------------------------
		   以下は座標の算出とデータの平均化処理(複数人検出用)
		--------------------------------------------------------*/
		calc_data_xyt(scan_data,scan_data_xyt);		//得られたデータをx,y,theta表現に変換する
		set_malti_xyt(malti_flag, scan_data, malti_trace, center_angl_other, malti_object_xyt);	//複数オブジェクトの位置を推定する

		//ここまでで複数オブジェクト[i]の位置座標が推定された
		//-------------------------------------------
		// 代表方向カウント　::center_angl_other[i]
		// x座標[mm]		 ::malti_object_xyt[i][0]
		// y座標[mm]		 ::malti_object_xyt[i][1]
		// 角度 [rad]		 ::malti_object_xyt[i][2]
		//-------------------------------------------

		object_connect(center_angl_other,malti_object_xyt,scan_data,filter_ex_point,m_connect_size);	//複数オブジェクト同士で距離の近いもの同士を1つにまとめ、間のデータを補完する
		fill_flag(exist_flag, filter_ex_point, move_trace);	//まとめたオブジェクト同士の間にある空白部分において、フラグを立てる
		
		/*--------------------------------------------------------
		   以下は座標の算出とデータの平均化処理(追尾対象検出用)
		--------------------------------------------------------*/
		center_angl=center_angl_maker(move_trace,scan_data,&onece,&onece2,&bf_dist,&bf_senter_angl,&lost_swich,m_lost_limit,&lost_swich2);	//暴走を防ぎながら中心角度を算出する
		object_xyt[2]=(center_angl-384)*2*PI/1024;			//目標の代表方向にあたる角度をラジアンで計算
		main_dist=scan_data[center_angl];
		object_xyt[0]=-1*main_dist*sin(object_xyt[2]);		//代表方向のX座標をdoubleで計算
		object_xyt[1]=main_dist*cos(object_xyt[2]);			//代表方向のY座標をdoubleで計算
		
		
		//追尾対象オブジェクトの位置座標が推定された
		//-------------------------------------------
		// 代表方向カウント　::center_angl
		// x座標[mm]		 ::object_xyt[0]
		// y座標[mm]		 ::object_xyt[1]
		// 角度 [rad]		 ::object_xyt[2]
		//-------------------------------------------

		/*---------------------------
		   モーターを駆動させる処理
		---------------------------*/
		m_Target_Pos.data=-object_xyt[2]/2/PI*360;	//水平方向制御モーターに指示を出す
		m_Target_PosOut.write();
		m_Target_Pos2.data=atan((double)1000/scan_data[center_angl])/2/PI*360;	//垂直方向制御モーターに指示を出す
		m_Target_Pos2Out.write();

		/*---------------------------
		   表示と初期化を行う処理
		---------------------------*/
		std::cout << "----------------------------------" << std::endl;
		std::cout << "Target_Position_X:"<< object_xyt[0] << "[mm]" << std::endl;
		std::cout << "Target_Position_Y:"<< object_xyt[1] << "[mm]" << std::endl;
		std::cout << "Pan_Motor :" << m_Target_Pos.data << "[deg]" << std::endl;
		std::cout << "Tilt_Motor:" << m_Target_Pos2.data << "[deg]" << std::endl;
		std::cout << "----------------------------------" << std::endl;

		clear_variable(malti_flag,malti_trace,filter_ex_point,move_trace);
		
	}

  return RTC::RTC_OK;
}

/*!
 * エラー状態に遷移したことを通知する処理
 */

RTC::ReturnCode_t Tracking_Controller::onAborting(RTC::UniqueId ec_id)
{
	std::cout << "----------------------------------" << std::endl;
	std::cout << "Error occurred"<< std::endl;
	std::cout << "reset this Component" << std::endl;
	std::cout << "----------------------------------" << std::endl;
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t Tracking_Controller::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Tracking_Controller::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Tracking_Controller::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Tracking_Controller::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/



extern "C"
{
 
  void Tracking_ControllerInit(RTC::Manager* manager)
  {
    coil::Properties profile(tracking_controller_spec);
    manager->registerFactory(profile,
                             RTC::Create<Tracking_Controller>,
                             RTC::Delete<Tracking_Controller>);
  }
  
};



/*---------------------------------
　　　　　以下は追加関数
---------------------------------*/

////////////////////////////////////////////////////////////////////////////　　密度の低い部分を除外する関数
bool strong_pass_filter(int s_range, int limit, bool flag[], int trace[], int s_data[])
{
	int filter_on=0;
	//密度の弱いデータをフィルタ処理
	for(int i = 44;i <= 725;i++)
	{
		filter_on=0;
		if(flag[i]==1)
		{
			for(int filter_count=1;filter_count<s_range;filter_count++)		//各データの前後指定カウントを検査
			{
				if((i-filter_count)<0 || (i-filter_count)>=800)
				{
					std::cout << "--------------------------"<< std::endl;
					std::cout << "Inaccurate parameter!!"<< std::endl;
					std::cout << "m_stpass_range="<< s_range << std::endl;
					std::cout << "--------------------------"<< std::endl;
					return FALSE;   //不適切なs_rangeによって想定外のメモリ領域に書き込ませない
				} 
				if(flag[i-filter_count]==1)filter_on++;
				if(flag[i+filter_count]==1)filter_on++;
			}
			if(filter_on<limit)			//検査領域に有効データが指定個数以下な場合はデータを無効化（ノイズの除去）
			{
				flag[i]=0;
				trace[0]-=1;
				trace[1]-=i;
				s_data[i]=0;
			}
		}
	}
return TRUE;
}

////////////////////////////////////////////////////////////////////////////　　密度の高い箇所にある欠落データを補完する関数
bool weak_pass_filter(int s_range, int limit, bool flag[], int trace[], int s_data[])
{
	//密度の濃い中にある穴を埋める（ノイズの補完）
	int average_dist=0;
	int average_count=0;
	for(int i = 44;i <= 725;i++)
	{
		average_dist=0;
		average_count=0;
		if(flag[i]==0){
			int filter_on_bk=0;
			int filter_on_fr=0;
			for(int filter_count=1;filter_count<=s_range;filter_count++)		//各データの前後指定カウントを検査
			{
				if((i-filter_count)<0 || (i-filter_count)>=800 || (i+filter_count)<0 || (i+filter_count)>=800)
				{
					std::cout << "--------------------------"<< std::endl;
					std::cout << "Inaccurate parameter!!"<< std::endl;
					std::cout << "m_wkpass_range="<< s_range << std::endl;
					std::cout << "--------------------------"<< std::endl;
					return FALSE;   //不適切なs_rangeによって想定外のメモリ領域に書き込ませない
				} 
				if(flag[i+filter_count]==1)
				{
					filter_on_fr++;
					average_dist+=s_data[i+filter_count];
					average_count++;
				}
				if(flag[i-filter_count]==1)
				{
					filter_on_bk++;
					average_dist+=s_data[i-filter_count];	
					average_count++;	
				}
			}
			if(filter_on_bk>limit){			//検査領域に有効データが指定個数以上な場合はデータをまとめる
				if(filter_on_fr>limit)
				{
					flag[i]=1;
					trace[0]+=1;
					trace[1]+=i;
					s_data[i]=average_dist/average_count;  //無理やり有効データ扱いにしたので中には周辺有効データ平均を代入
				}
			}
		}
	}
return TRUE;
}

////////////////////////////////////////////////////////////////////////////　　複数のオブジェクトを分割する関数
bool parson_devid_method(int s_range, int limit, int delsize, bool flag[], bool D_flag[][800], int D_trace[][2])
{
	//複数人の人検出
	int parson_id=1;
	for(int i = 44;i <= 725;i++)
	{
		if(parson_id<5)
		{
			if(flag[i]==1)
			{
				int filter_on=0;
				for(int filter_count=1;filter_count<=s_range;filter_count++)		//各データの前指定カウントを検査
				{
					if((i+filter_count)<0 || (i+filter_count)>=800)
					{
						std::cout << "--------------------------"<< std::endl;
						std::cout << "Inaccurate parameter!!"<< std::endl;
						std::cout << "m_pdevide_range="<< s_range << std::endl;
						std::cout << "--------------------------"<< std::endl;
						return FALSE;   //不適切なs_rangeによって想定外のメモリ領域に書き込ませない
					}
					if(flag[i+filter_count]==1)filter_on++;
				}
				if(filter_on>limit)			//検査領域に有効データが指定個以上な場合はデータをまとめる
				{
					D_flag[parson_id][i]=1;
					D_trace[parson_id][0]+=1;
					D_trace[parson_id][1]+=i;
				}
				else
				{
					D_flag[parson_id][i]=0;
					if(D_trace[parson_id][0]<=delsize)
					{
						D_trace[parson_id][0]=0;
						D_trace[parson_id][1]=0;
						for(int j = 44;j <= 725;j++)
						{
							D_flag[parson_id][j]=0;
						}
					}
					else parson_id++;
				}
			}		
		}
	}
return TRUE;
}

////////////////////////////////////////////////////////////////////////////　　対象物の測定点から一定の角度、距離のデータを除外する関数
void lock_on_method(int one, bool flag[], int dist, int range, int trace[], int s_data[])
{
	int pre_angle=0;
	pre_angle=calc_center_angle(trace);
	//最もデータの強い場所（人のいる場所）のみを有効データとする
	if(onece>=10){
		for(int i = 44;i <= 725;i++){
			if(flag[i]==1){
				if(abs(i-pre_angle)>range){
					flag[i]=0;
					trace[0]-=1;
					trace[1]-=i;
				}
				else if(abs(s_data[pre_angle]-s_data[i])>dist){
					flag[i]=0;
					trace[0]-=1;
					trace[1]-=i;							
				}
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////　　複数オブジェクトに関してロックオンを行う関数
void lock_on_method_maltiweak(int one, bool D_flag[][800], int dist, int range, int D_trace[][2], int s_data[])
{
	int pre_malti_angle[5]={0};
	for(int i=1;i<5;i++)
	{
		if(D_trace[i][0]==0) pre_malti_angle[i]=0;
		else pre_malti_angle[i]=calc_center_angle(D_trace[i]);
	}
	//複数人検出でもデータの強い場所（人のいる場所）のみを有効データとする
	if(onece>=10){
		for(int i=1 ;i<5;i++)
		{
			if(pre_malti_angle[i]!=0)
			{
				for(int j = 44;j <= 725;j++)
				{
					if(D_flag[i][j]==1)
					{
						if(abs(i-pre_malti_angle[i])>range)
						{
							D_flag[i][j]=0;
							D_trace[i][0]-=1;
							D_trace[i][1]-=j;
						}
						else if(abs(s_data[pre_malti_angle[i]]-s_data[j])>dist)
						{
							D_flag[i][j]=0;
							D_trace[i][0]-=1;
							D_trace[i][1]-=j;							
						}
					}
				}
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////　　代表角度を計算する処理
int calc_center_angle(int trace[])
{
	int calc_angl;
	if(trace[0]>=5) calc_angl=trace[1]/trace[0];	//目標の代表方向にあたるスキャン数を計算
	else calc_angl=384;											//有効データが全くない場合はとりあえず中心を指定
	if(calc_angl<0 || calc_angl>800)
	{
		calc_angl=384;
	}
	return calc_angl;
}

////////////////////////////////////////////////////////////////////////////　　代表方向を計算し暴走させないようにする処理
int center_angl_maker(int trace[], int s_data[], int *one, int *one2, double *pre_dist, int *pre_center_angle, int *l_swich, int l_limit, int *l_swich2)
{
	int angl=calc_center_angle(trace);		//0<angl<=800であることはcalc_center_angleで保証されている

	//代表方向を暴走させないように工夫
	//代表角度が飛んだ時の対応
	if(one2==0)
	{
		*pre_center_angle=angl;		//ループの最初で変数の整合性を保つためにとりあえず保存
		*one2=1;					//この処理は1回しか行わない（2回目以降やると内容的に意味なし）
		*pre_dist=s_data[angl];		
	}
	
	if(angl==384)
	{							//代表方向が中心のとき（有効データが無いとき）
		if(one>0)
		{
			angl=*pre_center_angle;	//かつループ初期でないときは過去データを利用
		}
		l_swich++;								//目標を見失っているのでロストスイッチ変数を増やす
		if(*l_swich==l_limit){					//ロストスイッチ変数が10溜まったら
			one=0;									//次のループで初期動作（目標を見つける処理）を実行させる
			one2=0;									//次のループで初期動作（過去データをとりあえず保存する処理）を実行させる
			l_swich=0;								//ロストスイッチ変数をリセットする
			std::cout<< "lost_swich ON!!" << std::endl;
		}
	}
	else if(abs(*pre_center_angle-angl)>=500)	//代表方向が大きく外れたとき
	{
		if(*one>0)
		{
			angl=*pre_center_angle;	//かつループ初期でないときは過去データを利用
		}
		*l_swich++;								//目標を見失っているのでロストスイッチ変数を増やす
		if(*l_swich==l_limit)					//ロストスイッチ変数が10溜まったら
		{
			*one=0;									//次のループで初期動作（目標を見つける処理）を実行させる
			*one2=0;									//次のループで初期動作（過去データをとりあえず保存する処理）を実行させる
			*l_swich=0;								//ロストスイッチ変数をリセットする
			std::cout<< "lost_swich ON!!" << std::endl;
		}	
	}
	else											//代表方向が中心でないとき（有効データがあるとき）
	{
		*l_swich=0;								//ロストスイッチ変数を初期化
		*pre_center_angle=angl;					//代表方向スキャン数を過去データとして保存
		
	}

	//代表方向距離が飛んだ時の対応
	if(s_data[angl]==0){						//代表方向長さが0のとき（有効データが無いとき）
		if(one>0){s_data[angl]=*pre_dist;}	//かつループ初期でないときは過去データを利用
		*l_swich2++;									//目標を見失っているのでロストスイッチ変数を増やす
		if(*l_swich2==l_limit){				//ロストスイッチ変数が10溜まったら
		*one=0;									//次のループで初期動作（目標を見つける処理）を実行させる
		*one2=0;									//次のループで初期動作（過去データをとりあえず保存する処理）を実行させる
		*l_swich2=0;								//ロストスイッチ変数をリセットする
		std::cout<< "lost_swich2 ON!!" << std::endl;
		}
	}
	else if(abs(*pre_dist-s_data[angl])>=1000){		//代表長さが大きく（1m以上）外れたとき
		if(*one>0){s_data[angl]=*pre_dist;}			//かつループ初期でないときは過去データを利用
		l_swich2++;											//目標を見失っているのでロストスイッチ変数を増やす
		if(*l_swich2==l_limit){				//ロストスイッチ変数が10溜まったら
		*one=0;									//次のループで初期動作（目標を見つける処理）を実行させる
		*one2=0;									//次のループで初期動作（過去データをとりあえず保存する処理）を実行させる
		*l_swich2=0;								//ロストスイッチ変数をリセットする
		std::cout<< "lost_swich2 ON!!" << std::endl;
		}	
	}
	else{										//代表方向が中心でないとき（有効データがあるとき）
		*l_swich2=0;							//ロストスイッチ変数を初期化
		*pre_dist=s_data[angl];		//代表方向スキャン数を過去データとして保存
	}
	return angl;
}

////////////////////////////////////////////////////////////////////////////　　背景との差分が一定割合以上の箇所を検出する関数
void bkscan_compare(int f_data[], int s_data[], double rate, bool flag[], int trace[])
{
	for(int i = 44;i <= 725;i++)
	{
		if(f_data[i]!=0)				//環境データが得られた場合（fieldデータが0でないとき）
		{
			if(s_data[i]/f_data[i]<rate)		//フィールドデータよりも一定割合以下の場合は物体があると判断
			{
				if(s_data[i]>100){		//データが10cm以下の場合は無視（ノイズ除去のため）
					flag[i]=1;		//データが有効な場所のフラグを立てる
					trace[0]+=1;					//有効データ数をカウント
					trace[1]+=i;					//有効データの総カウント数を算出
				}
				else
				{
					flag[i]=0;			//無効データ場合はフラグを折る
				}
			}
			else
			{
				flag[i]=0;			//無効データ場合はフラグを折る
			}
		}

		else								//環境データが得られなかった場合（fieldデータが0のとき）
		{
			if(s_data[i]!=0)			//取得データが0以外のとき（環境データの無い箇所に有効データ＝物体がある）
			{
				flag[i]=1;			//データが有効な場所のフラグを立てる
				trace[0]+=1;						//有効データ数をカウント
				trace[1]+=i;						//有効データの総カウント数を算出
				//field_data[i1]=scan_data[i1];
			}
			else
			{
				flag[i]=0;			//無効データ箇所にデータなしのときはフラグを折る
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////　　得られたデータをx,y,theta表現に変換する
void calc_data_xyt(int s_data[], double xyt[][800])
{
	for(int i=44 ; i<=725 ; i++){
		xyt[2][i]=(i-384)*2*PI/1024;				//ラジアン単位の角度算出
		xyt[0][i]=-1*s_data[i]*sin(xyt[2][i]);	//double型でX座標を計算
		xyt[1][i]=s_data[i]*cos(xyt[2][i]);		//double型でY座標を計算
	}
}

////////////////////////////////////////////////////////////////////////////　　複数人のx,y,thetaを決定する
void set_malti_xyt(bool D_flag[][800], int s_data[], int D_trace[][2], int c_angl_other[], double malti_xyt[][3])
{
	int start[5]={725,725,725,725,725};
	int end[5]={0,0,0,0,0};
	int add_long=0;
	int add_num=0;
	int ave_long=0;
	double c_dist_other[5]={0};

	for(int i=1;i<5;i++)
	{
		//オブジェクトの距離を平均化する処理
		for(int j=44 ; j<=725 ; j++)
		{
			if(D_flag[i][j]==1)
			{
				if(j<start[i])start[i]=j;
				if(j>end[i])end[i]=j;
			}
		}
		start[i]=start[i]+5;
		end[i]=end[i]-5;
		for(int i2=start[i];i2<=end[i];i2++)			//開始点と終了点が分かったので間のデータを全てその平均で代表させる
		{
			if(D_flag[i][i2]==1)
			{
				add_long+=s_data[i2];
				add_num+=1;
			}
			if(add_num!=0)
			{
				ave_long=add_long/add_num;
				for(int i2=start[i];i2<=end[i];i2++)
				{
					s_data[i2]=ave_long;
				}
			}
		}
		c_angl_other[i]=calc_center_angle(D_trace[i]);
		malti_xyt[i][2]=(c_angl_other[i]-384)*2*PI/1024;				//目標の代表方向にあたる角度をラジアンで計算
		c_dist_other[i]=s_data[c_angl_other[i]];							//代表方向を示す線の距離を設定
		malti_xyt[i][0]=-1*c_dist_other[i]*sin(malti_xyt[i][2]);		//代表方向のX座標をdoubleで計算
		malti_xyt[i][1]=c_dist_other[i]*cos(malti_xyt[i][2]);			//代表方向のY座標をdoubleで計算
	}
}

////////////////////////////////////////////////////////////////////////////　　複数オブジェクトのうち距離が一定値以下のオブジェクト同士を結合する
void object_connect(int c_angl_other[],double malti_xyt[][3],int s_data[],bool ex_point[], int c_size)
{
	double malti_human_xyt[5][3]={0};
	double human_long=0;

	for(int i=1;i<5;i++)
	{
		if(c_angl_other[i]!=0)
		{
			for(int comb=1;comb<=4;comb++)		//[i]と[i-comb]を比較する(2,1)(3,1)(3,2)(4,1)(4,2)(4,3)
			{
				if(c_angl_other[i-comb]!=0){
					if(i>comb)
					{
						double delta_x=abs(malti_xyt[i][0]-malti_xyt[i-comb][0]);
						double delta_y=abs(malti_xyt[i][1]-malti_xyt[i-comb][1]);
						if((delta_x*delta_x+delta_y*delta_y)<(c_size*c_size))
						{
							malti_human_xyt[i][0]=abs(malti_xyt[i][0]+malti_xyt[i-comb][0])/2;
							malti_human_xyt[i][1]=abs(malti_xyt[i][1]+malti_xyt[i-comb][1])/2;
							if((malti_human_xyt[i][0]*malti_human_xyt[i][0]+malti_human_xyt[i][1]*malti_human_xyt[i][1])!=0)
								{
								human_long=sqrt(malti_human_xyt[i][0]*malti_human_xyt[i][0]+malti_human_xyt[i][1]*malti_human_xyt[i][1]);
							}
							for(int j=0;j<(c_angl_other[i]-c_angl_other[i-comb])/2+5;j++)	//結合したオブジェクト間のスキャン回数だけ繰り返し（上下から計算で/2）
							{
								int angl_a=c_angl_other[i]-j;
								int angl_b=c_angl_other[i-comb]+j;
								if(angl_a>0 && angl_a<800)s_data[angl_a]=human_long;  //無理やり有効データ扱いにしたので有効データ平均を代入
								if(angl_b>0 && angl_b<800)s_data[angl_b]=human_long;
								ex_point[angl_a]=1;
								ex_point[angl_b]=1;
							}
						}
					}
				}
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////　　オブジェクトの接合処理後に間の空間のフラグを穴埋めする処理
void fill_flag(bool flag[], bool ex_point[], int trace[])
{
	for(int i = 44;i <= 725;i++)
	{
		if(flag[i]==0)
		{
			if(ex_point[i]==1)
			{
				flag[i]=1;
				trace[0]+=1;
				trace[1]+=i;
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////　　引数の初期化をする処理
void clear_variable(bool D_flag[][800], int D_trace[][2], bool ex_point[], int trace[])
{
	for(int ii=1;ii<5;ii++)
	{
		for(int iii=44;iii<=725;iii++)
		{
			D_flag[ii][iii]=0;
		}
		D_trace[ii][0]=0;
		D_trace[ii][1]=0;
	}
	//フィルターポイントの初期化
	for(int ii=40;ii<=725;ii++)
	{
		ex_point[ii]=0;
	}
	trace[0]=0;
	trace[1]=0;
}