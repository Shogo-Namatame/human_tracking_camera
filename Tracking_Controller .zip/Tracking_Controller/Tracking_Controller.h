// -*- C++ -*-
/*!
 * @file  Tracking_Controller.h
 * @brief Controller
 * @date  $Date$
 *
 * @author Shogo Namatame
 *
 * 修正BSDライセンス
 *
 * $Id$
 */

#ifndef TRACKING_CONTROLLER_H
#define TRACKING_CONTROLLER_H

#include <rtm/Manager.h>
#include <rtm/DataFlowComponentBase.h>
#include <rtm/CorbaPort.h>
#include <rtm/DataInPort.h>
#include <rtm/DataOutPort.h>
#include <rtm/idl/BasicDataTypeSkel.h>
#include <rtm/idl/ExtendedDataTypesSkel.h>
#include <rtm/idl/InterfaceDataTypesSkel.h>

// Service implementation headers
// <rtc-template block="service_impl_h">

// </rtc-template>

// Service Consumer stub headers
// <rtc-template block="consumer_stub_h">

// </rtc-template>

using namespace RTC;

/*!
 * @class Tracking_Controller
 * @brief Controller
 *
 * LRFのデータを基に人の位置を判別し、モーターに指示を出すコンポーネント
 *
 * LRFのスキャンデータを受け取り、モーターへの動作指示を出力する
 *
 * 背景のスキャンデータを最初に取得し、現在との差分を取ることで人を識別する。
 *
 */

bool strong_pass_filter(int s_range,int limit, bool flag[], int trace[], int s_data[]);
bool weak_pass_filter(int s_range, int limit, bool flag[], int trace[], int s_data[]);
bool parson_devid_method(int s_range, int limit, int delsize, bool flag[], bool D_flag[][800], int D_trace[][2]);
void lock_on_method_maltiweak(int one, bool D_flag[][800], int dist, int range, int D_trace[][2], int s_data[]);
void lock_on_method(int one, bool flag[], int dist, int range, int trace[], int s_data[]);
int calc_center_angle(int trace[]);
int center_angl_maker(int trace[], int s_data[], int *one, int *one2, double *pre_dist, int *pre_center_angle, int *l_swich, int l_limit, int *l_swich2);
void bkscan_compare(int f_data[], int s_data[], double rate, bool flag[], int trace[]);
void calc_data_xyt(int s_data[], double xyt[][800]);
void set_malti_xyt(bool D_flag[][800], int s_data[], int D_trace[][2], int c_angl_other[], double malti_xyt[][3]);
void object_connect(int c_angl_other[],double malti_xyt[][3],int s_data[],bool ex_point[],int c_size);
void fill_flag(bool flag[], bool ex_point[], int trace[]);
void clear_variable(bool D_flag[][800], int D_trace[][2], bool ex_point[], int trace[]);

class Tracking_Controller
  : public RTC::DataFlowComponentBase
{
 public:
  /*!
   * @brief constructor
   * @param manager Maneger Object
   */
  Tracking_Controller(RTC::Manager* manager);

  /*!
   * @brief destructor
   */
  ~Tracking_Controller();

  // <rtc-template block="public_attribute">
  
  // </rtc-template>

  // <rtc-template block="public_operation">
  
  // </rtc-template>

  /***
   * 各変数を初期化する処理
   *
   * The initialize action (on CREATED->ALIVE transition)
   * formaer rtc_init_entry() 
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onInitialize();

  /***
   * 
   *
   * The finalize action (on ALIVE->END transition)
   * formaer rtc_exiting_entry()
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onFinalize();

  /***
   *
   * The startup action when ExecutionContext startup
   * former rtc_starting_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onStartup(RTC::UniqueId ec_id);

  /***
   *
   * The shutdown action when ExecutionContext stop
   * former rtc_stopping_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onShutdown(RTC::UniqueId ec_id);

  /***
   * field_dataを取得する処理
   *
   * The activated action (Active state entry action)
   * former rtc_active_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onActivated(RTC::UniqueId ec_id);

  /***
   *
   * The deactivated action (Active state exit action)
   * former rtc_active_exit()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onDeactivated(RTC::UniqueId ec_id);

  /***
   * LRFのデータを取得し人を抽出、モーターに人追跡の動作指示を出す処理
   *
   * The execution action that is invoked periodically
   * former rtc_active_do()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * @pre LRFから正常にデータが送られている
   * 
   */
   virtual RTC::ReturnCode_t onExecute(RTC::UniqueId ec_id);

  /***
   * エラー状態に遷移したことを通知する処理
   *
   * The aborting action when main logic error occurred.
   * former rtc_aborting_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onAborting(RTC::UniqueId ec_id);

  /***
   *
   * The error action in ERROR state
   * former rtc_error_do()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onError(RTC::UniqueId ec_id);

  /***
   *
   * The reset action that is invoked resetting
   * This is same but different the former rtc_init_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onReset(RTC::UniqueId ec_id);
  
  /***
   *
   * The state update action that is invoked after onExecute() action
   * no corresponding operation exists in OpenRTm-aist-0.2.0
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onStateUpdate(RTC::UniqueId ec_id);

  /***
   *
   * The action that is invoked when execution context's rate is changed
   * no corresponding operation exists in OpenRTm-aist-0.2.0
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onRateChanged(RTC::UniqueId ec_id);


 protected:
  // <rtc-template block="protected_attribute">
  
  // </rtc-template>

  // <rtc-template block="protected_operation">
  
  // </rtc-template>

  // Configuration variable declaration
  // <rtc-template block="config_declare">
  /*!
   * strong_pass_filter内の検査範囲指定変数
   * - Name: stpass_range stpass_range
   * - DefaultValue: 10
   * - Range: 0<=x<=40
   */
  int m_stpass_range;
  /*!
   * strong_pass_filterで使用するデータ削除闘値
   * - Name: stpass_limit stpass_limit
   * - DefaultValue: 5
   */
  int m_stpass_limit;
  /*!
   * weak_pass_filter内の検査範囲指定変数
   * - Name: wkpass_range wkpass_range
   * - DefaultValue: 10
   * - Range: 0<=x<=40
   */
  int m_wkpass_range;
  /*!
   * strong_pass_filterで使用するデータ削除闘値
   * - Name: wkpass_limit wkpass_limit
   * - DefaultValue: 5
   */
  int m_wkpass_limit;
  /*!
   * parson_diveide_method内の検査範囲指定変数
   * - Name: pdevide_range pdevide_range
   * - DefaultValue: 10
   * - Range: 0<=x<=40
   */
  int m_pdevide_range;
  /*!
   * parson_devide_methodで使用するデータ分割闘値
   * - Name: pdevide_limit pdevide_limit
   * - DefaultValue: 0
   */
  int m_pdevide_limit;
  /*!
   * parson_devide_methodで使用するデータ削除闘値
   * - Name: pdevide_delsize pdevide_delsize
   * - DefaultValue: 5
   */
  int m_pdevide_delsize;
  /*!
   * カメラ追従対象をロックオンする際に、この範囲以上のフラグは全て折られる
   * - Name: cut_range cut_range
   * - DefaultValue: 40
   */
  int m_cut_range;
  /*!
   * 複数オブジェクトをロックオンする際に、この範囲以上のフラグは全て折られる
   * - Name: cut_range_other cut_range_other
   * - DefaultValue: 100
   */
  int m_cut_range_other;
  /*!
   * カメラ追従対象ロックオン時、奥行きがこの範囲を超えた場所のフラグは全て折られ
   * る
   * - Name: cut_dist cut_dist
   * - DefaultValue: 500
   */
  int m_cut_dist;
  /*!
   * 複数物体ロックオン時、奥行きがこの範囲を超えた場所のフラグは全て折られる
   * - Name: cut_dist_other cut_dist_other
   * - DefaultValue: 500
   */
  int m_cut_dist_other;
  /*!
   * この値の回数だけ追従対象が見つからない時は現在角度をリセットする
   * - Name: lost_limit lost_limit
   * - DefaultValue: 50
   */
  int m_lost_limit;
  /*!
   * スキャンしたデータがこの距離以上な場合はデータを0にする
   * - Name: max_dist max_dist
   * - DefaultValue: 2000
   */
  int m_max_dist;
  /*!
   * 初期測定時の環境と比較してこの割合以下のデータがある場所に物があると認識する
   * - Name: object_rate object_rate
   * - DefaultValue: 0.8
   */
  double m_object_rate;
  /*!
   * この値以下の距離だけ近づいたオブジェクト同士は1つにまとめられる
   * - Name: connect_size connect_size
   * - DefaultValue: 100
   * - Unit: mm
   */
  int m_connect_size;
  // </rtc-template>

  // DataInPort declaration
  // <rtc-template block="inport_declare">
  RangeData m_scan;
  /*!
   * LRFから送られてきたデータを受け取るポート
   * - Type: RangeData
   * - Semantics: LRFのスキャンデータ
   * - Unit: mm
   */
  InPort<RangeData> m_scanIn;
  
  // </rtc-template>


  // DataOutPort declaration
  // <rtc-template block="outport_declare">
  TimedLong m_Target_Pos;
  /*!
   * モーターへ人追尾の動作指示を出すポート
   * - Type: TimedLong
   * - Semantics: パン軸モーターへの動作指示
   * - Unit: degree
   */
  OutPort<TimedLong> m_Target_PosOut;
  TimedLong m_Target_Pos2;
  /*!
   * モーターへ人追尾の動作指示を出すポート
   * - Type: TimedLong
   * - Semantics: チルト軸モーターへの動作指示
   * - Unit: degree
   */
  OutPort<TimedLong> m_Target_Pos2Out;
  
  // </rtc-template>

  // CORBA Port declaration
  // <rtc-template block="corbaport_declare">
  
  // </rtc-template>

  // Service declaration
  // <rtc-template block="service_declare">
  
  // </rtc-template>

  // Consumer declaration
  // <rtc-template block="consumer_declare">
  
  // </rtc-template>

 private:
  // <rtc-template block="private_attribute">
  
  // </rtc-template>

  // <rtc-template block="private_operation">
  
  // </rtc-template>

};


extern "C"
{
  DLL_EXPORT void Tracking_ControllerInit(RTC::Manager* manager);
};

#endif // TRACKING_CONTROLLER_H
