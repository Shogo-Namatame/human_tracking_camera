// -*- C++ -*-
/*!
 * @file  Maxon_motor.cpp
 * @brief Motor_driver
 * @date $Date$
 *
 * @author Shogo Namatame
 * b09074@shibaura-it.ac.jp
 *
 * 修正BSDライセンス
 *
 * $Id$
 */

#include "Maxon_motor.h"
#include "Definitions.h"

#define PI 3.14159265358979 /* 円周率 */
DWORD m_ulErrorCode;
HANDLE m_KeyHandle;
bool Device_connection=FALSE;
bool Servo_state=FALSE;
char DeviceName[]={"EPOS2"};
char ProtocolStackName[]={"MAXON_SERIAL_V2"};
char InterfaceName[]={"USB"};
char PortName[]={"USB0"};

// Module specification
// <rtc-template block="module_spec">
static const char* maxon_motor_spec[] =
  {
    "implementation_id", "Maxon_motor",
    "type_name",         "Maxon_motor",
    "description",       "Motor_driver",
    "version",           "1.0.0",
    "vendor",            "Shogo Namatame",
    "category",          "Motor_driver",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "0",
    "language",          "C++",
    "lang_type",         "compile",
    // Configuration variables
    "conf.default.usNodeId", "1",
    "conf.default.bMode", "0",
    "conf.default.ulProfileVelocity", "500",
    "conf.default.ulProfileAcceleration", "5000",
    "conf.default.ulProfileDeceleration", "5000",
    "conf.default.lStartPosition", "0",
    "conf.default.abs_mode", "1",
    "conf.default.set_Position", "0",
    "conf.default.range_limit", "90",
    "conf.default.gear_para", "90",
    "conf.default.DeviceName", "EPOS2",
    "conf.default.ProtocolStackName", "MAXON_SERIAL_V2",
    "conf.default.InterfaceName", "USB",
    "conf.default.PortName", "USB0",
    // Widget
    "conf.__widget__.usNodeId", "text",
    "conf.__widget__.bMode", "text",
    "conf.__widget__.ulProfileVelocity", "text",
    "conf.__widget__.ulProfileAcceleration", "text",
    "conf.__widget__.ulProfileDeceleration", "text",
    "conf.__widget__.lStartPosition", "text",
    "conf.__widget__.abs_mode", "radio",
    "conf.__widget__.set_Position", "text",
    "conf.__widget__.range_limit", "text",
    "conf.__widget__.gear_para", "text",
    "conf.__widget__.DeviceName", "radio",
    "conf.__widget__.ProtocolStackName", "radio",
    "conf.__widget__.InterfaceName", "text",
    "conf.__widget__.PortName", "radio",
    // Constraints
    "conf.__constraints__.abs_mode", "(0,1)",
    "conf.__constraints__.DeviceName", "(EPOS,EPOS2)",
    "conf.__constraints__.ProtocolStackName", "(MAXON_SERIAL_V2,MAXON_RS232,CANopen)",
    "conf.__constraints__.InterfaceName", "USB",
    "conf.__constraints__.PortName", "(USB0,USB1)",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
Maxon_motor::Maxon_motor(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_Target_PosIn("Target_Pos", m_Target_Pos),
    m_Now_PosOut("Now_Pos", m_Now_Pos)

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
Maxon_motor::~Maxon_motor()
{
}


/*!
 * 各変数の初期化を行う
 */
RTC::ReturnCode_t Maxon_motor::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  addInPort("Target_Pos", m_Target_PosIn);
  
  // Set OutPort buffer
  addOutPort("Now_Pos", m_Now_PosOut);
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

  // <rtc-template block="bind_config">
  // Bind variables and configuration variable
  bindParameter("usNodeId", m_usNodeId, "1");
  bindParameter("bMode", m_bMode, "0");
  bindParameter("ulProfileVelocity", m_ulProfileVelocity, "500");
  bindParameter("ulProfileAcceleration", m_ulProfileAcceleration, "5000");
  bindParameter("ulProfileDeceleration", m_ulProfileDeceleration, "5000");
  bindParameter("lStartPosition", m_lStartPosition, "0");
  bindParameter("abs_mode", m_abs_mode, "1");
  bindParameter("set_Position", m_set_Position, "0");
  bindParameter("range_limit", m_range_limit, "90");
  bindParameter("gear_para", m_gear_para, "90");
  bindParameter("DeviceName", m_DeviceName, "EPOS2");
  bindParameter("ProtocolStackName", m_ProtocolStackName, "MAXON_SERIAL_V2");
  bindParameter("InterfaceName", m_InterfaceName, "USB");
  bindParameter("PortName", m_PortName, "USB0");
  
  // </rtc-template>
  return RTC::RTC_OK;
}

/*!
 * EPOSとの通信切断処理
 */

RTC::ReturnCode_t Maxon_motor::onFinalize()
{
	if(Servo_state==TRUE)
	{
		std::cout << "Servo OFF!!" << std::endl;
		if(DeviceDisable(m_KeyHandle,m_usNodeId,&m_ulErrorCode))	//サーボが入っているならば落とす
		{
			Servo_state=FALSE;
		}
	}
	if(Device_connection==TRUE)
	{
		RestoreEPOS(m_KeyHandle, m_usNodeId, &m_ulErrorCode,
		m_ulProfileVelocity, m_ulProfileAcceleration, m_ulProfileDeceleration, m_bMode);			//EPOSと接続されていれば落とす
		m_KeyHandle=NULL;
		Device_connection=FALSE;
	}
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t Maxon_motor::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Maxon_motor::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*!
 * EPOSに接続する処理
 */

RTC::ReturnCode_t Maxon_motor::onActivated(RTC::UniqueId ec_id)
{
	strcpy(DeviceName,m_DeviceName.c_str());
	strcpy(ProtocolStackName,m_ProtocolStackName.c_str());
	strcpy(DeviceName,m_DeviceName.c_str());
	strcpy(PortName,m_PortName.c_str());

	if(Device_connection==TRUE)
	{
		if(Servo_state==FALSE)
		{
			if(DeviceEnable(m_KeyHandle, m_usNodeId, &m_ulErrorCode))		//既にEPOSに接続されているならばサーボON
			{
				std::cout << "Servo ON!!" << std::endl;
				Servo_state=TRUE;
			}
		}
	}
	else
	{
		std::cout << "Try Open Device\n" << std::endl;
		if(OpenDevice(DeviceName, ProtocolStackName, InterfaceName, PortName, &m_ulErrorCode, &m_KeyHandle, m_usNodeId, &m_bMode,
					  m_ulProfileVelocity, m_ulProfileAcceleration, m_ulProfileDeceleration, &m_lStartPosition))		//EPOSに接続されていないならば接続
		{
			Device_connection=TRUE;
			if(Servo_state==FALSE)
			{
				if(DeviceEnable(m_KeyHandle, m_usNodeId, &m_ulErrorCode))			//既にEPOSに接続されているならばサーボON
				{
					std::cout << "Servo ON!!" << std::endl;
					Servo_state=TRUE;
				}
			}
		}
		else
		{
			//--------------------------
			//エラー告知文は関数内に記述
			//--------------------------
			return RTC::RTC_ERROR;
		}
	}

return RTC::RTC_OK;
}

/*!
 * モーターの駆動を停止させる（サーボを落とす）
 */

RTC::ReturnCode_t Maxon_motor::onDeactivated(RTC::UniqueId ec_id)
{
	if(Servo_state==TRUE)
	{
		std::cout << "Servo OFF!!" << std::endl;
		if(DeviceDisable(m_KeyHandle,m_usNodeId,&m_ulErrorCode))		//サーボが入っているならば落とす
		{
			Servo_state=FALSE;
		}
	}
	
	if(Device_connection==TRUE)
	{
		RestoreEPOS(m_KeyHandle, m_usNodeId, &m_ulErrorCode,
					m_ulProfileVelocity, m_ulProfileAcceleration, m_ulProfileDeceleration, m_bMode);			//EPOSと接続されていれば落とす
		m_KeyHandle=NULL;
		Device_connection=FALSE;
	}
	

  return RTC::RTC_OK;
}

/*!
 * InPortから角度指示値データを取得し、EPOSを介してモーターを動作させる
 */

RTC::ReturnCode_t Maxon_motor::onExecute(RTC::UniqueId ec_id)
{
	if (m_Target_PosIn.isNew())
	{
		if(m_Target_PosIn.read())
		{
			std::cout << "Data is " << m_Target_Pos.data << std::endl;
			if(m_Target_Pos.data<m_range_limit && m_Target_Pos.data>-m_range_limit)
			{
				m_set_Position=m_Target_Pos.data*m_gear_para;
				if(MotorMove(m_KeyHandle, m_usNodeId, &m_lStartPosition,
							  &m_ulErrorCode, m_set_Position, m_abs_mode))		//モーター駆動処理(入力値チェック済み)
				{
					if(m_abs_mode==TRUE)
					{
						m_Now_Pos.data=m_set_Position/m_gear_para;
					}
					else
					{
						m_Now_Pos.data=(m_lStartPosition+m_set_Position)/m_gear_para;
					}
					m_Now_PosOut.write();
				}
				else
				{
					//--------------------------
					//エラー告知文は関数内に記述
					//--------------------------
					return RTC::RTC_ERROR;
				}
			}
			//INPORTから読み込んだデータが設定した範囲外の値である時
			else
			{
				std::cout << "----------------------------------------" << std::endl;
				std::cout << "Data=" << m_Target_Pos.data << " is out range!!" << std::endl;
				std::cout << "Configuration range is ( " << m_range_limit << "<Data<" << -m_range_limit << " )" << std::endl;
				std::cout << "If you want use this Data, Change Configuration parameter" << std::endl;
				std::cout << "----------------------------------------" << std::endl;
			}
		}
		//INPORTからデータが正常に読み込めなかったとき
		else
		{
			std::cout << "----------------------------------------" << std::endl;
			std::cout << "Can't read INPORT " << std::endl;
			std::cout << "When m_Target_PosIn.read() is called"<< std::endl;
			std::cout << "----------------------------------------" << std::endl;
		}
	}

  return RTC::RTC_OK;
}

/*!
 * エラー発生時にモーターの駆動をを停止させる処理（サーボを落とす）
 */

RTC::ReturnCode_t Maxon_motor::onAborting(RTC::UniqueId ec_id)
{
	if(Servo_state==TRUE)
	{
		std::cout << "Servo OFF!!" << std::endl;
		if(DeviceDisable(m_KeyHandle,m_usNodeId,&m_ulErrorCode))		//サーボがかかっていれば落とす
		{
			Servo_state=FALSE;
		}
	}
  return RTC::RTC_OK;
}

/*!
 * モーターが誤動作しないように静止させておく
 */

RTC::ReturnCode_t Maxon_motor::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}

/*!
 * エラーからの回復処理
 */

RTC::ReturnCode_t Maxon_motor::onReset(RTC::UniqueId ec_id)
{
	//再接続処理
	if(Device_connection==FALSE){
		std::cout << "Open Device Again" << std::endl;
		if(!OpenDevice(DeviceName, ProtocolStackName, InterfaceName, PortName, &m_ulErrorCode, &m_KeyHandle, m_usNodeId, &m_bMode,
					   m_ulProfileVelocity, m_ulProfileAcceleration, m_ulProfileDeceleration, &m_lStartPosition))
		{
			//--------------------------
			//エラー告知文は関数内に記述
			//--------------------------
			return RTC::RTC_ERROR;
		}
	}

	//エラーを消去する
	UpdateNodeIdString(&m_usNodeId);
	ErrorClear(m_KeyHandle, m_usNodeId, &m_ulErrorCode);

  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t Maxon_motor::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Maxon_motor::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/



extern "C"
{
 
  void Maxon_motorInit(RTC::Manager* manager)
  {
    coil::Properties profile(maxon_motor_spec);
    manager->registerFactory(profile,
                             RTC::Create<Maxon_motor>,
                             RTC::Delete<Maxon_motor>);
  }
  
};



/*------------------------
  　 以下は追加関数
------------------------*/
////////////////////////////////////////////////////////////////////////////　　NodeIdを更新する関数
void UpdateNodeIdString(DWORD *usNodeId)
{
	DWORD NodeId=*usNodeId;
	const size_t size(3);

    char strNodeId[size];

    _itoa_s(NodeId, strNodeId, size, 10);
	*usNodeId=NodeId;
}

////////////////////////////////////////////////////////////////////////////　　EPOSに接続する関数
bool OpenDevice(char *DName, char *PStackName, char *IName, char *PName, DWORD *ulErrorCode, HANDLE *KeyHandle, DWORD usNodeId, char *bMode
	, DWORD ulProfileVelocity, DWORD ulProfileAcceleration, DWORD ulProfileDeceleration, long *lStartPosition)
{
    const char PROFILE_POSITION_MODE(0x01);
	HANDLE hNewKeyHandle;

	//アンダーバーを半角スペースに変換
	for(int i=0;i<16;i++)
	{
		if(PStackName[i]=='_')PStackName[i]=' ';
	}
	hNewKeyHandle = VCS_OpenDevice(DName, PStackName, IName, PName, ulErrorCode);	//設定されたパラメーターで接続を試みる
	if(!hNewKeyHandle)
	{
		std::cout << "Auto Connection Failed"<< std::endl;
		std::cout << "Use Dialog Connection"<< std::endl;
		hNewKeyHandle = VCS_OpenDeviceDlg(ulErrorCode);	//ダイアログを用いたパラメーター選択式の接続を試みる
	}
	else
    {
		std::cout << "Auto Connection Success!!"<< std::endl;
    }

    if(hNewKeyHandle)
    {
		int error_point=0;
        //Close Previous Device
        if(*KeyHandle)
		{
			VCS_CloseDevice(*KeyHandle, ulErrorCode);
			std::cout << "Close Device" << std::endl;
		}
        *KeyHandle = hNewKeyHandle;
        //Clear Error History
        if(VCS_ClearFault(*KeyHandle, usNodeId, ulErrorCode))
        {
			error_point=1;
            //Read Operation Mode
            if(VCS_GetOperationMode(*KeyHandle, usNodeId, bMode, ulErrorCode))
            {
				error_point=2;
				//Write Profile Position Mode
				if(VCS_SetOperationMode(*KeyHandle, usNodeId, PROFILE_POSITION_MODE, ulErrorCode))
				{
					error_point=3;
		            //Write Profile Position Objects
			        if(VCS_SetPositionProfile(*KeyHandle, usNodeId, ulProfileVelocity, ulProfileAcceleration, ulProfileDeceleration, ulErrorCode))
				    {
						error_point=4;
						std::cout << "Setting Parameters----------------" << std::endl;
						std::cout << " ulProfileVelocity="<< ulProfileVelocity << std::endl;
						std::cout << " ulProfileAcceleration="<< ulProfileAcceleration << std::endl;
						std::cout << " ulProfileDeceleration="<< ulProfileDeceleration << std::endl;
						std::cout << "----------------------------------" << std::endl;
	                    //Read Actual Position
		                if(VCS_GetPositionIs(*KeyHandle, usNodeId, lStartPosition, ulErrorCode))
			            {
							std::cout << "Success Open Device!!"<< std::endl;
							Device_connection=TRUE;
						    return TRUE;
						}
					}
                }
            }
        }
		std::cout << "-------------------------------------"<< std::endl;
		std::cout << "Faile Device Connection " << std::endl;
		std::cout << "Reset Component and try connection again " << std::endl;
		std::cout << "Error =" << m_ulErrorCode << "  line:" << error_point << std::endl;
		if(error_point==3)std::cout << "The value of a parameter is inaccurate" << std::endl;
		std::cout << "-------------------------------------"<< std::endl;
		m_KeyHandle=NULL;
		Device_connection=FALSE;
    }
    else
    {
		std::cout << "-------------------------------------"<< std::endl;
		std::cout << "Can't Open Device!!"<< std::endl;
		std::cout << "Check paramerter and Reset Compornent"<< std::endl;
		std::cout << "-------------------------------------"<< std::endl;
		m_KeyHandle=NULL;
		Device_connection=FALSE;
    }

    return FALSE;
}

////////////////////////////////////////////////////////////////////////////　　動作出来るようにする関数
bool DeviceEnable(HANDLE KeyHandle, DWORD usNodeId, DWORD *ulErrorCode)
{

    UpdateNodeIdString(&usNodeId);
    ErrorClear(KeyHandle, usNodeId, ulErrorCode);

    if(!VCS_SetEnableState(KeyHandle, usNodeId, ulErrorCode))
    {
		std::cout << "-------------------------------------"<< std::endl;
		std::cout << "Can't Srvo ON"<< std::endl;
		std::cout << "When VCS_SetEnableState() is called"<< std::endl;			
        std::cout << "Error =" << m_ulErrorCode << std::endl;
		std::cout << "-------------------------------------"<< std::endl;
		return FALSE;
    }
return TRUE;
}

////////////////////////////////////////////////////////////////////////////　　モーター接続切断、サーボオフ処理
bool DeviceDisable(HANDLE KeyHandle, DWORD usNodeId, DWORD *ulErrorCode)
{
	if(!VCS_SetDisableState(KeyHandle,usNodeId,ulErrorCode))
    {
		std::cout << "-------------------------------------"<< std::endl;
		std::cout << "Can't Servo OFF"<< std::endl;
		std::cout << "When VCS_SetDisableState() is called"<< std::endl;			
        std::cout << "Error =" << m_ulErrorCode << std::endl;
		std::cout << "-------------------------------------"<< std::endl;
		return FALSE;
    }
return TRUE;
}

////////////////////////////////////////////////////////////////////////////　　EPOSと切断する処理
bool RestoreEPOS(HANDLE KeyHandle, DWORD usNodeId, DWORD *ulErrorCode, DWORD ulProfileVelocity, DWORD ulProfileAcceleration, DWORD ulProfileDeceleration, char bMode)
{
	VCS_SetDisableState(KeyHandle,usNodeId,ulErrorCode);
	VCS_SetOperationMode(KeyHandle,usNodeId,bMode,ulErrorCode);
	VCS_SetPositionProfile(KeyHandle,usNodeId,ulProfileVelocity,ulProfileAcceleration,ulProfileDeceleration,ulErrorCode);

	if(VCS_CloseAllDevices(ulErrorCode))
	{
		std::cout << "Device Closed" << std::endl;
	}
	else
	{
		std::cout << "Can't Device Closed" << std::endl;

	}

    return TRUE;
}

////////////////////////////////////////////////////////////////////////////　　エラーを取り消す処理
bool ErrorClear(HANDLE KeyHandle, DWORD usNodeId, DWORD *ulErrorCode)
{
	BOOL oFault = FALSE;
    if(!VCS_GetFaultState(KeyHandle, usNodeId, &oFault, ulErrorCode))
    {
        std::cout << "Error =" << ulErrorCode << std::endl;
		return FALSE;
    }

    if(oFault)
    {
        if(!VCS_ClearFault(KeyHandle, usNodeId, ulErrorCode))
        {
            std::cout << "Error =" << ulErrorCode << std::endl;
			return FALSE;
        }
    }
return TRUE;
}

////////////////////////////////////////////////////////////////////////////　　モーターを駆動させる処理(入力値のチェックは済んでいる前提)
bool MotorMove(HANDLE KeyHandle, DWORD usNodeId, long *lStartPosition,  DWORD *ulErrorCode, long set_data, int abs_mode)
{
	if(VCS_GetPositionIs(KeyHandle, usNodeId, lStartPosition, ulErrorCode))
	{
		//モーターが正常に動作できなかったとき
		if(!VCS_MoveToPosition(KeyHandle, usNodeId, set_data, abs_mode, TRUE, ulErrorCode))		//EPOSに角度指示値を送信する処理
		{
			std::cout << "-------------------------------------"<< std::endl;
			std::cout << "Can't motor move"<< std::endl;
			std::cout << "When VCS_MoveToPosition() is called"<< std::endl;
			std::cout << "Error =" << ulErrorCode << std::endl;
			std::cout << "-------------------------------------"<< std::endl;
			return FALSE;
		}
	}
	//位置データを習得するのに失敗したとき
	else
	{
		std::cout << "-------------------------------------"<< std::endl;
		std::cout << "Can't get position Data"<< std::endl;
		std::cout << "When VCS_GetToPositionIs() is called"<< std::endl;
		std::cout << "Error =" << ulErrorCode << std::endl;
		std::cout << "-------------------------------------"<< std::endl;
		return FALSE;
	}
return TRUE;
}