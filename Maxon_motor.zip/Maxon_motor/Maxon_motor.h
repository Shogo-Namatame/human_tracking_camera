// -*- C++ -*-
/*!
 * @file  Maxon_motor.h
 * @brief Motor_driver
 * @date  $Date$
 *
 * @author Shogo Namatame
 * b09074@shibaura-it.ac.jp
 *
 * 修正BSDライセンス
 *
 * $Id$
 */

#ifndef MAXON_MOTOR_H
#define MAXON_MOTOR_H

#include <rtm/Manager.h>
#include <rtm/DataFlowComponentBase.h>
#include <rtm/CorbaPort.h>
#include <rtm/DataInPort.h>
#include <rtm/DataOutPort.h>
#include <rtm/idl/BasicDataTypeSkel.h>
#include <rtm/idl/ExtendedDataTypesSkel.h>
#include <rtm/idl/InterfaceDataTypesSkel.h>

// Service implementation headers
// <rtc-template block="service_impl_h">

// </rtc-template>

// Service Consumer stub headers
// <rtc-template block="consumer_stub_h">

// </rtc-template>

using namespace RTC;

/*!
 * @class Maxon_motor
 * @brief Motor_driver
 *
 * InPortから得られた角度指令値をEPOSに送り、モーターの位置決めを行うコンポーネン
 * ト
 *
 * InPortから得られたデータをEPOSに送る
 *
 * 取得したデータをEPOS用に整理して送信する
 *
 * マクソンモータ（株）が公開しているライブラリとサンプルプログラムの一部を利用
 *
 */

void UpdateNodeIdString(DWORD *usNodeId);		//EPOS接続に使用するNodeIdの更新処理
bool OpenDevice(char *DName, char *PStackName, char *IName, char *PName, DWORD *ulErrorCode, HANDLE *KeyHandle, DWORD usNodeId, char *bMode,
				DWORD ulProfileVelocity, DWORD ulProfileAcceleration, DWORD ulProfileDeceleration, long *lStartPosition);				//EPOSとの初期接続を行う処理
bool DeviceEnable(HANDLE KeyHandle, DWORD usNodeId, DWORD *ulErrorCode);			//モーターを駆動出来る状態にする(サーボON)
bool DeviceDisable(HANDLE KeyHandle, DWORD usNodeId, DWORD *ulErrorCode);	//モーターを駆動出来ない状態にする(サーボOFF)
bool RestoreEPOS(HANDLE KeyHandle, DWORD usNodeId, DWORD *ulErrorCode,
	             DWORD ulProfileVelocity, DWORD ulProfileAcceleration, DWORD ulProfileDeceleration, char bMode);	//EPOSとの接続を切断する
bool MotorMove(HANDLE KeyHandle, DWORD usNodeId, long *lStartPosition,
			   DWORD *ulErrorCode, long set_data, int oRadio);			//実際にモーターへ角度指示を出す処理
bool ErrorClear(HANDLE KeyHandle, DWORD usNodeId, DWORD *ulErrorCode);	//発生したエラーを消去する処理



class Maxon_motor
  : public RTC::DataFlowComponentBase
{
 public:
  /*!
   * @brief constructor
   * @param manager Maneger Object
   */
  Maxon_motor(RTC::Manager* manager);

  /*!
   * @brief destructor
   */
  ~Maxon_motor();

  // <rtc-template block="public_attribute">
  
  // </rtc-template>

  // <rtc-template block="public_operation">
  
  // </rtc-template>

  /***
   * 各変数の初期化を行う
   *
   * The initialize action (on CREATED->ALIVE transition)
   * formaer rtc_init_entry() 
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onInitialize();

  /***
   * EPOSとの通信切断処理
   *
   * The finalize action (on ALIVE->END transition)
   * formaer rtc_exiting_entry()
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onFinalize();

  /***
   *
   * The startup action when ExecutionContext startup
   * former rtc_starting_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onStartup(RTC::UniqueId ec_id);

  /***
   *
   * The shutdown action when ExecutionContext stop
   * former rtc_stopping_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onShutdown(RTC::UniqueId ec_id);

  /***
   * EPOSに接続する処理
   *
   * The activated action (Active state entry action)
   * former rtc_active_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * @pre EPOSの配線が正しく行われている
   * 
   */
   virtual RTC::ReturnCode_t onActivated(RTC::UniqueId ec_id);

  /***
   * モーターの駆動を停止させる（サーボを落とす）
   *
   * The deactivated action (Active state exit action)
   * former rtc_active_exit()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onDeactivated(RTC::UniqueId ec_id);

  /***
   * InPortから角度指示値データを取得し、EPOSを介してモーターを動作させる
   *
   * The execution action that is invoked periodically
   * former rtc_active_do()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * @pre EPOSと正しく通信が出来ていること
   * 
   */
   virtual RTC::ReturnCode_t onExecute(RTC::UniqueId ec_id);

  /***
   * エラー発生時にモーターの駆動をを停止させる処理（サーボを落とす）
   *
   * The aborting action when main logic error occurred.
   * former rtc_aborting_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onAborting(RTC::UniqueId ec_id);

  /***
   * モーターが誤動作しないように静止させておく
   *
   * The error action in ERROR state
   * former rtc_error_do()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onError(RTC::UniqueId ec_id);

  /***
   * エラーからの回復処理
   *
   * The reset action that is invoked resetting
   * This is same but different the former rtc_init_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onReset(RTC::UniqueId ec_id);
  
  /***
   *
   * The state update action that is invoked after onExecute() action
   * no corresponding operation exists in OpenRTm-aist-0.2.0
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onStateUpdate(RTC::UniqueId ec_id);

  /***
   *
   * The action that is invoked when execution context's rate is changed
   * no corresponding operation exists in OpenRTm-aist-0.2.0
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onRateChanged(RTC::UniqueId ec_id);


 protected:
  // <rtc-template block="protected_attribute">
  
  // </rtc-template>

  // <rtc-template block="protected_operation">
  
  // </rtc-template>

  // Configuration variable declaration
  // <rtc-template block="config_declare">
  /*!
   * 複数のEPOSを個別に制御するための変数
   * EPOS基盤上のスライドスイッチと対応
   * - Name: usNodeId usNodeId
   * - DefaultValue: 1
   */
  DWORD m_usNodeId;
  /*!
   * EPOSのモードを設定する変数
   * - Name: char bMode
   * - DefaultValue: 0
   */
  char m_bMode;
  /*!
   * 取得した現在設定の速度指令値
   * - Name: ulProfileVelocity ulProfileVelocity
   * - DefaultValue: 500
   */
  DWORD m_ulProfileVelocity;
  /*!
   * 取得した現在設定の加速度指令値
   * - Name: ulProfileAcceleration ulProfileAcceleration
   * - DefaultValue: 5000
   */
  DWORD m_ulProfileAcceleration;
  /*!
   * 取得した現在設定の減速度指令値
   * - Name: ulProfileDeceleration ulProfileDeceleration
   * - DefaultValue: 5000
   */
  DWORD m_ulProfileDeceleration;
  /*!
   * 初期動作時の角度を表す値
   * - Name: lStartPosition lStartPosition
   * - DefaultValue: 0
   */
  long int m_lStartPosition;
  /*!
   * 角度指令の方法を選択する変数
   * 0：相対座標指令
   * 1：絶対座標指令
   * - Name: oRadio abs_mode
   * - DefaultValue: 1
   */
  bool m_abs_mode;
  /*!
   * モーター動作時、新たに設定する位置指令値
   * - Name: set_Position set_Position
   * - DefaultValue: 0
   */
  long int m_set_Position;
  /*!
   * モーターの動作限界角度範囲
   * - Name: range_limit range_limit
   * - DefaultValue: 90
   */
  int m_range_limit;
  /*!
   * ギアとエンコーダーの分解能などの固有値によって決まる動作定数
   * - Name: gear_para gear_para
   * - DefaultValue: 90
   */
  long int m_gear_para;
  /*!
   * 
   * - Name: DeviceName DeviceName
   * - DefaultValue: EPOS2
   * - Range: (EPOS,EPOS2)
   */
  std::string m_DeviceName;
  /*!
   * 
   * - Name: ProtocolStackName ProtocolStackName
   * - DefaultValue: MAXON_SERIAL_V2
   * - Range: (MAXON_SERIAL_V2,MAXON_RS232,CANopen)
   */
  std::string m_ProtocolStackName;
  /*!
   * 
   * - Name: InterfaceName InterfaceName
   * - DefaultValue: USB
   * - Range: USB
   */
  std::string m_InterfaceName;
  /*!
   * 
   * - Name: PortName PortName
   * - DefaultValue: USB0
   */
  std::string m_PortName;
  // </rtc-template>

  // DataInPort declaration
  // <rtc-template block="inport_declare">
  TimedLong m_Target_Pos;
  /*!
   * 角度指示値を取得するポート
   * - Type: TimedLong
   * - Semantics: モーターへ送る角度指示値
   * - Unit: degree
   */
  InPort<TimedLong> m_Target_PosIn;
  
  // </rtc-template>


  // DataOutPort declaration
  // <rtc-template block="outport_declare">
  TimedLong m_Now_Pos;
  /*!
   * 現在角度を出力するポート
   * - Type: TimedLong
   * - Unit: degree
   */
  OutPort<TimedLong> m_Now_PosOut;
  
  // </rtc-template>

  // CORBA Port declaration
  // <rtc-template block="corbaport_declare">
  
  // </rtc-template>

  // Service declaration
  // <rtc-template block="service_declare">
  
  // </rtc-template>

  // Consumer declaration
  // <rtc-template block="consumer_declare">
  
  // </rtc-template>

 private:
  // <rtc-template block="private_attribute">
  
  // </rtc-template>

  // <rtc-template block="private_operation">
  
  // </rtc-template>

};


extern "C"
{
  DLL_EXPORT void Maxon_motorInit(RTC::Manager* manager);
};

#endif // MAXON_MOTOR_H
