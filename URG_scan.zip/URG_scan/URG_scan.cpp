// -*- C++ -*-
/*!
 * @file  URG_scan.cpp
 * @brief LRF
 * @date $Date$
 *
 * @author Shogo Namatame
 * b09074@shibaura-it.ac.jp
 *
 * BSDライセンス
 *
 * $Id$
 */

#include "URG_scan.h"
#include "lrf_gdscan.h"

char comNo[]={"com0"};
urg_state_t urg_state;
long* data;
int max_size=0;

// Module specification
// <rtc-template block="module_spec">
static const char* urg_scan_spec[] =
  {
    "implementation_id", "URG_scan",
    "type_name",         "URG_scan",
    "description",       "LRF",
    "version",           "1.0.0",
    "vendor",            "Shogo Namatame",
    "category",          "Sensor",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    // Configuration variables
    "conf.default.comNo", "com1",
    // Widget
    "conf.__widget__.comNo", "text",
    // Constraints
    "conf.__constraints__.comNo", "(com1,com2,com3,com4,com5,com6,com7,com8,com9,com10,com11,com12,com13,com14,com15)",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
URG_scan::URG_scan(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_dataOut("LRF_Scan_Data", m_data)

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
URG_scan::~URG_scan()
{
}


/*!
 * 各変数の初期化を行う処理
 */
RTC::ReturnCode_t URG_scan::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  
  // Set OutPort buffer
  addOutPort("LRF_Scan_Data", m_dataOut);
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

  // <rtc-template block="bind_config">
  // Bind variables and configuration variable
  bindParameter("comNo", m_comNo, "com1");
  
  // </rtc-template>
  m_data.ranges.length(800);
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t URG_scan::onFinalize()
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t URG_scan::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t URG_scan::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*!
 * URGの計測を開始させる処理
 */

RTC::ReturnCode_t URG_scan::onActivated(RTC::UniqueId ec_id)
{
	strcpy(comNo,m_comNo.c_str());
	std::cout << "Try " << comNo << " Connect" << std::endl;
	//通信条件設定
	char com_port[] = {"com0"};		//comポート番号を指定
	memcpy(com_port,comNo,sizeof(comNo));
	const long com_baudrate = 115200;	//ボーレートを指定
	int ret = urg_connect(&urg_state, com_port, com_baudrate);	//URGに接続
	if (ret < 0)		//エラー判断
	{
		std::cout << "--------------------------" << std::endl;
		std::cout << "Can't connect URG " << std::endl;
		std::cout << "Error =" << ErrorMessage << std::endl;
		std::cout << "--------------------------" << std::endl;
		return RTC::RTC_ERROR;
	}
	else
	{
		std::cout << "URG Connect success!! " << std::endl;
	}
	max_size = urg_state.max_size;		//サイズを決定する変数（どうせ750くらいで一定だが）
	enum { CaptureTimes = 0 };			//何回計測するか決める（事実上無限回を表す「0」と指定）
	size_t total_index = 0;
	data = new long[max_size];		//取得データを格納する動的変数を定義（注意：deleteすること）
	std::cout << "First scan ....." << std::endl;
	urg_captureByMD(&urg_state, CaptureTimes);		//実際にデータを取得してみる
	std::cout << "First scan OK!!" << std::endl;
	delete data;
  return RTC::RTC_OK;
}

/*!
 * URGの計測を終了させる処理
 */

RTC::ReturnCode_t URG_scan::onDeactivated(RTC::UniqueId ec_id)
{
	std::cout << "URG scan Stop!!" << std::endl;
	int dummy=0;
	urg_sendMessage("QT", Timeout, &dummy);
	urg_disconnect();
  return RTC::RTC_OK;
}

/*!
 * 取得したデータ整理してをOutPortに出力する処理
 */

RTC::ReturnCode_t URG_scan::onExecute(RTC::UniqueId ec_id)
{
	data = new long[max_size];		//取得データを格納する動的変数を定義（注意：deleteすること）
	int n = urg_receiveData(&urg_state, data, max_size);	//データ取得の本操作
	if (n > 0)
	{
		for(int i1 = 44;i1 <= 725;i1++)		//得られたデータを保存変数に順次代入してゆく
		{
			m_data.ranges[i1] = data[i1];
		}
    std::cout << "Front Data ="<< m_data.ranges[384] << std::endl;
	m_dataOut.write();
	}
	else
	{
		std::cout << "Get data Failed " << std::endl;
		return RTC::RTC_ERROR;
	}
	delete data;
  return RTC::RTC_OK;
}

/*!
 * エラーが発生したときにURGの計測を止める処理
 */

RTC::ReturnCode_t URG_scan::onAborting(RTC::UniqueId ec_id)
{
	std::cout << "URG scan Stop!!" << std::endl;
	int dummy=0;
	urg_sendMessage("QT", Timeout, &dummy);
	urg_disconnect();
  return RTC::RTC_OK;
}

/*!
 * エラーが発生した場合の処理
 */

RTC::ReturnCode_t URG_scan::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}

/*!
 * エラーから回復する際に、正常終了しなかった状態を整える処理
 */

RTC::ReturnCode_t URG_scan::onReset(RTC::UniqueId ec_id)
{
	//URGを正常に終了しなかったときに備え、接続→計測→切断を一度行うことで正常に戻す
	strcpy(comNo,m_comNo.c_str());
	std::cout << comNo << std::endl;
	//通信条件設定
	char com_port[] = {"com0"};		//comポート番号を指定
	memcpy(com_port,comNo,sizeof(comNo));
	const long com_baudrate = 115200;	//ボーレートを指定
	int ret = urg_connect(&urg_state, com_port, com_baudrate);	//URGに接続

	max_size = urg_state.max_size;		//サイズを決定する変数（どうせ750くらいで一定だが）
	enum { CaptureTimes = 0 };			//何回計測するか決める（事実上無限回を表す「0」と指定）
	size_t total_index = 0;
	data = new long[max_size];		//取得データを格納する動的変数を定義（注意：deleteすること）
	urg_captureByMD(&urg_state, CaptureTimes);		//実際にデータを取得してみる
	delete data;
	int dummy=0;
	urg_sendMessage("QT", Timeout, &dummy);
	urg_disconnect();
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t URG_scan::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t URG_scan::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/



extern "C"
{
 
  void URG_scanInit(RTC::Manager* manager)
  {
    coil::Properties profile(urg_scan_spec);
    manager->registerFactory(profile,
                             RTC::Create<URG_scan>,
                             RTC::Delete<URG_scan>);
  }
  
};


